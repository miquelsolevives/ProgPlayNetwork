from setuptools import setup
setup(
    name="progplaynetwork",
    version="0.15",
    description="Progressive Play Network: Red mixta (zona-jugador) relativa al EPS para el análisis de la progresión en momento con balón frente a bloques medios y bajos",
    author="Miquel Solé",
    author_email="diguemmiquel@gmail.com",
    packages=['progplaynetwork'],
    scripts=[]
)